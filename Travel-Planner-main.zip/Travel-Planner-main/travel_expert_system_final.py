from pyknow import *

travel_list = []
travel_preferences = []
preferences_map = {}
t_desc_map = {}
t_itinerary_map = {}

def preprocess():
	global travel_list,travel_preferences,preferences_map,t_desc_map,t_itinerary_map
	travel = open("travel.txt")
	travel_t = travel.read()
	travel_list = travel_t.split("\n")
	travel.close()
	for travel in travel_list:
		travel_s_file = open("Travel Preferences/" + travel + ".txt")
		travel_s_data = travel_s_file.read()
		s_list = travel_s_data.split("\n")
		travel_preferences.append(s_list)
		preferences_map[str(s_list)] = travel
		travel_s_file.close()
		travel_s_file = open("Travel Description/" + travel + ".txt")
		travel_s_data = travel_s_file.read()
		t_desc_map[travel] = travel_s_data
		travel_s_file.close()
		travel_s_file = open("Travel Itinerary/" + travel + ".txt")
		travel_s_data = travel_s_file.read()
		t_itinerary_map[travel] = travel_s_data
		travel_s_file.close()
	

def identify_travel(*arguments):
	preferences_list = []
	for preferences in arguments:
		preferences_list.append(preferences)

	return preferences_map[str(preferences_list)]

def get_details(travel):
	return t_desc_map[travel]

def get_itinerary(travel):
	return t_itinerary_map[travel]

def if_not_matched(travel):
		print("")
		id_travel = travel
		travel_details = get_details(id_travel)
		itinerary = get_itinerary(id_travel)
		print("")
		print("The most probable destination that you wish to be in is %s\n" %(id_travel))
		print("A short description of the destination is given below :\n")
		print(travel_details+"\n")
		print("The common itinerary suggested by other guides are: \n")
		print(itinerary+"\n")

class Greetings(KnowledgeEngine):
	@DefFacts()
	def _initial_action(self):
		print("")
		print("Hi! I am Mike, I am here to help you make your travel experience better.")
		print("For that you'll have to answer a few questions about your preferences")
		print("Do you prefer any of these:")
		print("")
		yield Fact(action="find_travel")


	@Rule(Fact(action='find_travel'), NOT(Fact(honeymoon=W())),salience = 1)
	def preferences_0(self):
		self.declare(Fact(honeymoon=input("honeymoon: ")))

	@Rule(Fact(action='find_travel'), NOT(Fact(lakes=W())),salience = 1)
	def preferences_1(self):
		self.declare(Fact(lakes=input("lakes: ")))

	@Rule(Fact(action='find_travel'), NOT(Fact(desert=W())),salience = 1)
	def preferences_2(self):
		self.declare(Fact(desert=input("desert: ")))

	@Rule(Fact(action='find_travel'), NOT(Fact(temples=W())),salience = 1)
	def preferences_3(self):
		self.declare(Fact(temples=input("temples: ")))

	@Rule(Fact(action='find_travel'), NOT(Fact(activities=W())),salience = 1)
	def preferences_4(self):
		self.declare(Fact(activities=input("activities: ")))

	@Rule(Fact(action='find_travel'), NOT(Fact(kids=W())),salience = 1)
	def preferences_5(self):
		self.declare(Fact(kids=input("kids: ")))
	 
	@Rule(Fact(action='find_travel'), NOT(Fact(sanctuary=W())),salience = 1)
	def preferences_6(self):
		self.declare(Fact(sanctuary=input("sanctuary: ")))
	


	@Rule(Fact(action='find_travel'),Fact(honeymoon="Yes"),Fact(lakes="Yes"),Fact(desert="Yes"),Fact(temples="Yes"),Fact(activities="No"),Fact(kids="Yes"),Fact(sanctuary="No"))
	def travel_0(self):
		self.declare(Fact(travel="Udaipur"))

	@Rule(Fact(action='find_travel'),Fact(honeymoon="No"),Fact(lakes="Yes"),Fact(desert="No"),Fact(temples="Yes"),Fact(activities="No"),Fact(kids="Yes"),Fact(sanctuary="No"))
	def travel_1(self):
		self.declare(Fact(travel="Varanasi"))

	@Rule(Fact(action='find_travel'),Fact(honeymoon="No"),Fact(lakes="No"),Fact(desert="Yes"),Fact(temples="Yes"),Fact(activities="No"),Fact(kids="Yes"),Fact(sanctuary="No"))
	def travel_2(self):
		self.declare(Fact(travel="Ajmer"))

	@Rule(Fact(action='find_travel'),Fact(honeymoon="No"),Fact(lakes="Yes"),Fact(desert="No"),Fact(temples="Yes"),Fact(activities="Yes"),Fact(kids="No"),Fact(sanctuary="Yes"))
	def travel_3(self):
		self.declare(Fact(travel="Corbett"))

	@Rule(Fact(action='find_travel'),Fact(honeymoon="No"),Fact(lakes="No"),Fact(desert="No"),Fact(temples="No"),Fact(activities="Yes"),Fact(kids="Yes"),Fact(sanctuary="No"))
	def travel_4(self):
		self.declare(Fact(travel="Goa"))

	@Rule(Fact(action='find_travel'),Fact(honeymoon="Yes"),Fact(lakes="No"),Fact(desert="No"),Fact(temples="Yes"),Fact(activities="No"),Fact(kids="Yes"),Fact(sanctuary="No"))
	def travel_5(self):
		self.declare(Fact(travel="Jaipur"))

	@Rule(Fact(action='find_travel'),Fact(honeymoon="Yes"),Fact(lakes="Yes"),Fact(desert="No"),Fact(temples="No"),Fact(activities="Yes"),Fact(kids="No"),Fact(sanctuary="Yes"))
	def travel_6(self):
		self.declare(Fact(travel="Kashmir"))


	@Rule(Fact(action='find_travel'),Fact(travel=MATCH.travel),salience = -998)
	def travel(self, travel):
		print("")
		id_travel = travel
		travel_details = get_details(id_travel)
		itinerary = get_itinerary(id_travel)
		print("")
		print("The most probable destination that you can go to is %s\n" %(id_travel))
		print("A short description of the destination is given below :\n")
		print(travel_details+"\n")
		print("The common medications and procedures suggested by other real doctors are: \n")
		print(itinerary+"\n")

	@Rule(Fact(action='find_travel'),
		  Fact(honeymoon=MATCH.honeymoon),
		  Fact(lakes=MATCH.lakes),
		  Fact(desert=MATCH.desert),
		  Fact(temples=MATCH.temples),
		  Fact(activities=MATCH.activities),
		  Fact(kids=MATCH.kids),
		  Fact(sanctuary=MATCH.sanctuary),NOT(Fact(travel=MATCH.travel)),salience = -999)

	def not_matched(self,honeymoon,lakes,desert,temples,activities,kids,sanctuary):
		print("\nDid not find any destination that matches your exact preferences")
		lis = [honeymoon,lakes,desert,temples,activities,kids,sanctuary]
		max_count = 0
		max_travel = ""
		for key,val in preferences_map.items():
			count = 0
			temp_list = eval(key)
			for j in range(0,len(lis)):
				if(temp_list[j] == lis[j] and lis[j] == "Yes"):
					count = count + 1
			if count > max_count:
				max_count = count
				max_travel = val
		if_not_matched(max_travel)


if __name__ == "__main__":
	preprocess()
	engine = Greetings()
	while(TRUE):
		engine.reset()  
		engine.run()  
		print("Would you like to give some other preferences?")
		if input() == "No":
			exit()